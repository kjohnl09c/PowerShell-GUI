﻿##################################################
# Functions
##################################################
Function create_SessionID()
{
    $id = Get-Date -Format "-MMddyy"
    return $id
}

Function get_SessionID()
{
    $id = Get-Date -Format "-MMddyy"
    return $id
}

Function validate_SessionID( $ses1 )
{
    $validity  = $false

    $sess0 = get_SessionID

    Write-Host "Sesso: $sess0"
    Write-Host "Ses1: $ses1"

    if( $sess0.Equals( $ses1 ) )
    {
        $valid = $true
    
    } else {

        $valid = $false
    }

    return $valid
}

##################################################
# Session Settings
##################################################


##################################################
# Application Settings
##################################################