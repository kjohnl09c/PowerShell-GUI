﻿#Set Execution Policy
Set-ExecutionPolicy RemoteSigned

#Add the Presntation Framework to the script so that the WPF objects can run from 
#the powershell console
Add-Type -AssemblyName PresentationCore, PresentationFramework, System.Drawing
#########################################################################
#INCLUDED MODULES
#########################################################################
Import-Module ActiveDirectory

#########################################################################
#GET THE CURRENT PATH THE SCRIPT IS EXECUTING FROM
#########################################################################
$location = Split-Path $MyInvocation.MyCommand.Path -Parent

#########################################################################
#INCLUDED FILES
#########################################################################
$include = $location + "\includes\includes.ps1"
. $include

#########################################################################
#LOAD XAML CODE FROM FILE
#########################################################################
$myXamlPath = $location + "\xml\login.xml"
[xml]$xaml = Get-Content -Path $myXamlPath

#########################################################################
#CREATE THE WINDOW
#########################################################################
$Window = create_window $xaml


#########################################################################
#XAML NAME LINKS. MAPS PS NAMES TO XAML NAME MARKERS
#########################################################################
$nameLinks = $location + "\xaml_name_links.ps1"
. $nameLinks
$Global:home_img = $Window.FindName('Home')



#########################################################################
#BUTTONS
#########################################################################
#BUTTON DEFINITIONS 
$butPath = $location + "\button_def.ps1" 
. $butPath

#########################################################################
#MAIN
#########################################################################
#set home image
$imagePath = $location + "\images\login.png"
$Global:home_img.Source = $imagePath

#########################################################################
#SHOW THE WINDOW
#########################################################################
#Display the Window
$Window.ShowDialog() | Out-Null

