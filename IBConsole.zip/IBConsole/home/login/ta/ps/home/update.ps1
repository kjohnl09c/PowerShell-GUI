﻿Param(
    $Window
    )



$Window.ShowDialog() | Out-Null