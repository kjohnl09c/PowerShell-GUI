﻿Param(
    $location,
    $fileName,
    $Window    
    )

##########################################################################
# FUNCTIONS
##########################################################################
Function test_connection_to_server( $serverNm )
{

    $result = Test-Connection $serverNm

    if( $result.ReplySize -eq 32 )
    {
        $connection = $true
    
    } else {

        $connection = $false

    }
        
    return $connection

}


$Global:dhcp_jaxdhcp1 = $Window.FindName('jaxdhcp1')
$Global:dhcp_jaxvndhcp1 = $Window.FindName('jaxvndhcp1')
$Global:dhcp_phldhcp1224 = $Window.FindName('phldhcp1224')
$Global:dhcp_phldhcp1152 = $Window.FindName('phldhcp1152')
$Global:dhcp_phlvndhcp1 = $Window.FindName('phlvndhcp1')




##########################################################################
# READ THE CONTENTS OF THE SERVER NAMES FROM THE FILE
##########################################################################
$pathToFile = $location + "\ps\home\$fileName"
$myContents = Get-Content -Path $pathToFile






##########################################################################
# TEST THE SERVER NAME FOR AVAILABILITY
##########################################################################
foreach($item in $myContents)
{
    $myResult = test_connection_to_server $item

    Write-Host "Connection to $item is: $myResult"


    ###########################################################
    if(($item.equals("jaxdhcp1")) -and ($myResult -eq $true))
    {
        $Global:dhcp_jaxdhcp1.Background = "LightGreen"
    
    } else {

        $Global:dhcp_jaxdhcp1.Background = "Red"
    }
    ###########################################################
    if(($item.equals("jaxvndhcp1")) -and ($myResult -eq $true))
    {
        $Global:dhcp_jaxdhcp1.Background = "LightGreen"
    
    } else {

        $Global:dhcp_jaxdhcp1.Background = "Red"
    }
    ###########################################################
    if(($item.equals("phldhcp1224")) -and ($myResult -eq $true))
    {
        $Global:dhcp_jaxdhcp1.Background = "LightGreen"
    
    } else {

        $Global:dhcp_jaxdhcp1.Background = "Red"
    }
    ###########################################################
    if(($item.equals("phldhcp1152")) -and ($myResult -eq $true))
    {
        $Global:dhcp_jaxdhcp1.Background = "LightGreen"
    
    } else {

        $Global:dhcp_jaxdhcp1.Background = "Red"
    }
    ###########################################################
    if(($item.equals("phlvndhcp1")) -and ($myResult -eq $true))
    {
        $Global:dhcp_jaxdhcp1.Background = "LightGreen"
    
    } else {

        $Global:dhcp_jaxdhcp1.Background = "Red"
    }



}


#########################################################################
# XAML FILE LINKS
#########################################################################
$xaml_links = $location + "\xml\xaml_ps_links.ps1"
. $xaml_links
Test-Path -Path $xaml_links 


##########################################################################
# SET XAML BACKGROUND COLOR FOR SERVER NAME
##########################################################################

$pathToHomeXmlFile = $location + "\xml\home.xml"
Test-Path -Path $pathToHomeXmlFile



