﻿#Set Execution Policy
Set-ExecutionPolicy RemoteSigned

#Add the Presntation Framework to the script so that the WPF objects can run from 
#the powershell console
Add-Type -AssemblyName PresentationCore, PresentationFramework, System.Drawing

#########################################################################
#GET THE CURRENT PATH THE SCRIPT IS EXECUTING FROM
#########################################################################
$location = Split-Path $MyInvocation.MyCommand.Path -Parent

#########################################################################
#INCLUDED FILES
#########################################################################
$home_include = $location + "\includes\home_includes.ps1"
. $home_include

#########################################################################
#LOAD XAML CODE FROM FILE
#########################################################################
$path = $location + "\xml\home.xml"
[xml]$xaml = Get-Content -Path $path

#########################################################################
#CREATE THE WINDOW
#########################################################################
$Window = create_window $xaml


$Window.ShowDialog() | Out-Null
#########################################################################
#UPDATE SERVER STATUS
#########################################################################
#$fname = "dhcp_servers.txt"
#$path = $location + "\ps\home\"
#$command = "servers.ps1 -location $location -fileName $fname -Window $Window"
#$pathCom = $path + $command
#Invoke-Expression -Command $pathCom

#########################################################################
#SHOW THE WINDOW
#########################################################################
#Display the Window
#$Window.ShowDialog() | Out-Null
<#
$path = $location + "\ps\home\"
$command = ".\update.ps1 -Window $Window"
#$pathCom = $path + $command
Invoke-Expression -Command $command
#>



