﻿##############################################################################################################

Function create_window( $xaml_lcl )
{

    $reader=(New-Object System.Xml.XmlNodeReader $xaml_lcl )

    $myWindow=[Windows.Markup.XamlReader]::Load( $reader )

    return $myWindow
}

##############################################################################################################