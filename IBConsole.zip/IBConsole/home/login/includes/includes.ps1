﻿#############################################################################################################

Function createCredential($myUser, $myPasswd)
{
    $secpasswd = ConvertTo-SecureString $myPasswd -AsPlainText -Force
    $mycreds = New-Object System.Management.Automation.PSCredential ($myUser, $secpasswd)
    return $mycreds
}

##############################################################################################################

Function check_login( $UserName, $myPasswd )
{

    $valid = $false

    $cred = createCredential $UserName $myPasswd

    $id = $UserName.Split('\')

    $identity = $id[1]

    try
    {
        $value = Get-ADUser -Identity $identity -Credential $cred -ErrorAction SilentlyContinue
        
        
        if($value.Enabled -eq $true)
        {
            $valid = $true
            [System.Windows.MessageBox]::Show('Login Passed')
            
        } else {

            $valid = $false
        }
           

    } catch {
    
        [System.Windows.MessageBox]::Show('Login Failed')

        $valid = $false
        
    }
    
    return $valid
}

##############################################################################################################

Function create_window( $xaml_lcl )
{

    $reader=(New-Object System.Xml.XmlNodeReader $xaml_lcl )

    $myWindow=[Windows.Markup.XamlReader]::Load( $reader )

    return $myWindow
}

##############################################################################################################