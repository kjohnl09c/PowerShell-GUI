﻿
#include appset file
$appFile = $PSScriptRoot + "\appset.ps1"
. $appFile

$Global:Btn_Login.Add_Click({


    $uname = $Global:TB_User.Text
    $passt = $Global:TB_Pass.Text

    $name = $uname.Trim()
    $pass = $passt.Trim()
           
    $result = check_login $name $pass  
       
    if( $result -eq $true )
    { 
        $sesID = create_SessionID

        #Write-Host "SessionID created: $sesID"

        #.\check_login.ps1 -sessionID $sesID -windowlogin $Window
        .\check_login.ps1 -key $sesID -windowlogin $Window

    } else {

        Write-Host "authentication failed"
    }

       
})