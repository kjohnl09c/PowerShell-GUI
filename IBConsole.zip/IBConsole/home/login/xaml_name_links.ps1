﻿$Global:Btn_Login = $Window.FindName('Login')
$Global:TB_User = $Window.FindName('User')
$Global:TB_Pass = $Window.FindName('Pass')