﻿#Set Execution Policy
Set-ExecutionPolicy RemoteSigned

#Add the Presntation Framework to the script so that the WPF objects can run from 
#the powershell console
Add-Type -AssemblyName PresentationCore, PresentationFramework, System.Drawing


#########################################################################
#LOAD XAML CODE FROM FILE
#########################################################################
[xml]$xaml = Get-Content "C:\powershell\BasicWindowCode\basic.xml"
$reader=(New-Object System.Xml.XmlNodeReader $xaml )
$myWindow=[Windows.Markup.XamlReader]::Load( $reader )

#########################################################################
#CREATE THE WINDOW
#########################################################################
#$Window = create_window $xaml

#########################################################################
#SHOW THE WINDOW
#########################################################################
#Display the Window
$myWindow.ShowDialog() | Out-Null
